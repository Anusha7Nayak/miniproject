export class Product {
  id: number;
  _id: number;
  name: string;
  description: string;
  price: string;
}
