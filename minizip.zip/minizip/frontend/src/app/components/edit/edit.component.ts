import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder, Validators, FormControl } from "@angular/forms";
import { Router } from "@angular/router";
import { ProductService } from "src/app/service/product.service";

@Component({
  selector: "app-edit",
  templateUrl: "./edit.component.html",
  styleUrls: ["./edit.component.css"]
})
export class EditComponent implements OnInit {
  editForm: FormGroup;
  submitted: boolean = true;

  constructor(
    private formbuilder: FormBuilder,
    private router: Router,
    private productservice: ProductService
  ) {}

  ngOnInit() {
    if (localStorage.getItem("username") != null) {
      let productId = localStorage.getItem("editUserId");
      if (!productId) {
        alert("invalid action");
        this.router.navigate([""]);
        return;
      }
      this.productservice.getproductById(+productId).subscribe(data => {
        this.editForm.setValue(data);
        this.productservice.getproducts().subscribe();
      });
      this.editForm = new FormGroup({
        id:new FormControl(),
         _id: new FormControl("", [
         Validators.required,
         Validators.pattern("[0-9]{1,4}")
         
       ]),
       name: new FormControl("", [
         Validators.required,
         Validators.pattern("[A-Z][a-z]+")
       ]),
       description: new FormControl("", [Validators.required]),
       price: new FormControl("", Validators.required)
     });
    } else {
      this.router.navigate(["/login"]);
    }
  }
  onsubmit() {
    this.submitted = true;
    if (this.editForm.invalid) {
      return;
    }
    this.productservice.updateproduct(this.editForm.value).subscribe(data => {
      alert(this.editForm.value.name + "" + "record edited");
    });

    this.router.navigate([""]);
  }
}
